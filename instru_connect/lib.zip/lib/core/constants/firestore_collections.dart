class FirestoreCollections {
  static const users = 'users';
  static const notices = 'notices';
}
