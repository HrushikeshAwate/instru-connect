import 'package:flutter/material.dart';

class StaffHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: StaffHomeAppBar(),
      body: Column(
        children: [
          StaffHeader(),
          QuickActionsGrid(actions: staffActions),
          AssignedTasksList(),
        ],
      ),
    );
  }
}
