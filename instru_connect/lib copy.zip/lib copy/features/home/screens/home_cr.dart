import 'package:flutter/material.dart';

class CRHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CRHomeAppBar(),
      body: Column(
        children: [
          CRHeader(),
          QuickActionsGrid(actions: crActions),
          PendingTasksCard(),
          RecentNoticesList(),
        ],
      ),
      floatingActionButton: CreateNoticeFAB(),
    );
  }
}
