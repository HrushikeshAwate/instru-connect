import 'package:flutter/material.dart';

class StudentHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: StudentHomeAppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            StudentHeader(),
            QuickActionsGrid(actions: studentActions),
            TodayScheduleCard(),
            RecentNoticesList(),
          ],
        ),
      ),
    );
  }
}
