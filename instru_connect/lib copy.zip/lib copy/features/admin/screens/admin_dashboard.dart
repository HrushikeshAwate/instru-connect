import 'package:flutter/material.dart';

class AdminHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AdminHomeAppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            AdminHeader(),
            QuickActionsGrid(actions: adminActions),
            SystemStatsCard(),
          ],
        ),
      ),
    );
  }
}
