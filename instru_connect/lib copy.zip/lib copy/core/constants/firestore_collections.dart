class FirestoreCollections {
  static const users = 'users';
}
